﻿using Newtonsoft.Json;
using System;

namespace Bitratecalculationexercise
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string json = @"{
                              'Device': 'Arista',
                              'Model': 'X-Video',
                              'NIC': [
                                {
                                  'Description': 'Linksys ABR',
                                  'MAC': '14:91:82:3C:D6:7D',
                                  'Timestamp': '2020-03-23T18:25:43.511Z',
                                  'Rx': '3698574500',
                                  'Tx': '122558800'
                                }
                              ]
                            }";

            DeviceInfo deviceInfo = JsonConvert.DeserializeObject<DeviceInfo>(json);
            CalculateBitrates(deviceInfo, 2);
            Console.ReadKey();
        }

        static void CalculateBitrates(DeviceInfo deviceInfo, int pollingRateHz)
        {
            foreach (var nic in deviceInfo.NIC)
            {
                double pollingInterval = 1.0 / pollingRateHz; // Polling interval in seconds
                double rxBitrate = nic.Rx * 8.0 / pollingInterval; // Convert bytes to bits and divide by interval
                double txBitrate = nic.Tx * 8.0 / pollingInterval;

                Console.WriteLine($"NIC: {nic.Description}");
                Console.WriteLine($"Rx Bitrate: {rxBitrate} bps");
                Console.WriteLine($"Tx Bitrate: {txBitrate} bps");
            }
        }
    }
}